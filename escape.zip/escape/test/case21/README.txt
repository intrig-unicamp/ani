Infrastructure:     Multi-domain topo based on ETSI demo
Topology:           Multiple SBB domains: Mininet, Docker1,2, Openstack & Ryu
Request:            2-slice request for robot demo, 2 splitter, 4 balance server
Mapping:            1 layer orchestration, with mocked DOs
Expected result:    SUCCESS
