Infrastructure:     Standard mn topo managed by NFFG-based StaticFileAdapters
Topology:           standard 2EE-2SW topo with filled delay matrix
Request:            standard comp-decomp-fw
Mapping:            1 layer mapping
Expected result:    SUCCESS
