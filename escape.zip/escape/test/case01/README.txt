Infrastructure:     Mininet-based Infrastructure layer
Topology:           standard 2EE-2SW topo
Request:            standard comp-decomp-fw
Mapping:            1 layer orchestration
Expected result:    SUCCESS
