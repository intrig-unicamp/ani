Infrastructure:     1 domain managed by NFFG-based StaticFileAdapter
Topology:           static topology from SNDLib
Request:            dynamically generated requests to test E2E latency reqs
Mapping:            2 layer orchestration
Expected result:    SUCCESS
