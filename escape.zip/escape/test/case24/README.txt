Infrastructure:     1 domain managed by NFFG-based StaticFileAdapter
Topology:           3 merged UN domain with mapped NFs
Request:            Mover request with antiaffinity
Mapping:            1 layer mapping in REMAP mode, handles SAP ports in NFs
Expected result:    SUCCESS
