Infrastructure:     1 domain managed by NFFG-based StaticFileAdapter
Topology:           static topology from SNDLib
Request:            strict E2E delay reqs dynamically generated
Mapping:            2 layer orchestration
Expected result:    SUCCESS
