Infrastructure:     1 domain managed by NFFG-based StaticFileAdapter
Topology:           dynamically generated topology based on NetworkX graph
                    generator
Request:            dynamically generated request with balanced tree topology
                    created to test backtracking
Mapping:            2 layer orchestration
Expected result:    SUCCESS
