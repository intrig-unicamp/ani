Infrastructure:     1 domain managed by Virtualizer-based StaticFileAdapter
Topology:           standard 2EE-2SW topo in Virtualizer
Request:            standard comp-decomp-fw
Mapping:            1 layer orchestration
Expected result:    SUCCESS
