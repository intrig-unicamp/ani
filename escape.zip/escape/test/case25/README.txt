Infrastructure:     3 domain managed by Virtualizer-based StaticFileAdapter
Topology:           3 merged UN domain
Request:            Single balance server ADD and DELETE
Mapping:            1 layer mapping
Expected result:    SUCCESS
