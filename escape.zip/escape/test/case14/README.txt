Infrastructure:     1 domain managed by NFFG-based StaticFileAdapter
Topology:           dynamically generated topology
Request:            dynamically generated request
Mapping:            2 layer orchestration
Expected result:    SUCCESS
