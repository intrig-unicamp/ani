Infrastructure:     1 domain managed by NFFG-based StaticFileAdapter
Topology:           hwloc-generated topo on Intel Xeon E5-2620 (Rhea)
Request:            single decomp
Mapping:            1 layer orchestration
Expected result:    SUCCESS
