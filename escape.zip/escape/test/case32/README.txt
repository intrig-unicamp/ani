Infrastructure:     Standard mn topo managed by NFFG-based StaticFileAdapters
Topology:           robot-pidhelper setup
Request:            pid-pid-helper request with multiple SAP providers
Mapping:            1 layer mapping
Expected result:    SUCCESS
