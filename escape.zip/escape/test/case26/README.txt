Infrastructure:     2 domain managed by Virtualizer-based StaticFileAdapter
Topology:           2 merged ESCAPE domain
Request:            2 NF with anti-affinity considering in backtracking
Mapping:            1 layer mapping
Expected result:    SUCCESS
