Infrastructure:     Multi-domain topo based on EWSDN demo
Topology:           Multiple SBB domains: Mininet, Docker1,2, Openstack & Ryu
Request:            2-slice request for robot demo, 2 webserver, dpi, com-decomp
Mapping:            1 layer orchestration, without inter-domain link resources
Expected result:    SUCCESS
