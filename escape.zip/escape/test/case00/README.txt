Infrastructure:     Standard mn topo managed by NFFG-based StaticFileAdapters
Topology:           standard 2EE-2SW topo
Request:            standard comp-decomp-fw for NFFG field testing
Mapping:            No mapping
Expected result:    SUCCESS
