Infrastructure:     1 global DoV managed by NFFG-based StaticFileAdapters
Topology:           2 merged ESCAPE domain
Request:            Robot request with PID  helper and splitter
Mapping:            1 layer mapping
Expected result:    SUCCESS
