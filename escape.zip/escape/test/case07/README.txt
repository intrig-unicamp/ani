Infrastructure:     2 domains managed by Virtualizer-based StaticFileAdapters
Topology:           2 disjoint SBB topo based on 2EE-2SW merged via SAP14
Request:            standard comp-decomp-fw across domains
Mapping:            1 layer orchestration
Expected result:    SUCCESS
