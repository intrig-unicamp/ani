Infrastructure:     Standard mn topo managed by NFFG-based StaticFileAdapters
Topology:           standard 2EE-2SW topo
Request:            standard comp-decomp-fw with allowed_nodes constraint
Mapping:            1 layer mapping
Expected result:    SUCCESS
