Infrastructure:     Mininet-based Infrastructure layer
Topology:           standard 2EE-2SW topo
Request:            standard comp-decomp-fw
Mapping:            2 layer orchestration with SBB abstraction
Expected result:    SUCCESS
