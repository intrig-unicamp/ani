Infrastructure:     Standard dummy domains managed by NFFG-based StaticFileAdapter
Topology:           2 merged ESCAPE domain
Request:            1 isolated NF with no connections
Mapping:            1 layer mapping to test isolated NF ADD and DELETE
Expected result:    SUCCESS
