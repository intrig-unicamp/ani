Infrastructure:     2 domains managed by NFFG-based StaticFileAdapters
Topology:           2 disjoint standard 2EE-2SW topo merged via SAP14
Request:            standard comp-decomp-fw across domains
Mapping:            2 layer orchestration
Expected result:    SUCCESS
