Infrastructure:     1 domain managed by NFFG-based StaticFileAdapter
Topology:           static topology
Request:            generated 8-loop request graphs
Mapping:            2 layer orchestration
Expected result:    SUCCESS
